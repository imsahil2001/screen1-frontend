export interface cityState {
    city: string,
    state: string,

}