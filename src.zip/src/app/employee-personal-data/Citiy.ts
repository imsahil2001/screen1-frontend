export interface City {
   id: number,
   city: string,
   state_id: number
}