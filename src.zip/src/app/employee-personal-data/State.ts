export interface State {
   id: number,
   state: string
}