export interface MaritalStatus {
   id: number;
   maritalStatus: string,
   // martialStatus: string,
}