export interface Gender {
   id: number,
   gender: string;
}