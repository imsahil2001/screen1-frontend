export class Users {
    id: number;
    PState: string;
    PCity: string;
}
